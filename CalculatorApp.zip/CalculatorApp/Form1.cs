﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorApp
{
    public partial class Form1 : Form
    {

        double resultValue = 0;
        string operationPerformed = "";
        bool isoperationPerformed = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void button_click(object sender, EventArgs e)
        {
            if (tbDisplayResult.Text == "0" || isoperationPerformed)
                tbDisplayResult.Clear();

            isoperationPerformed = false;

            Button button = (Button)sender;
            if(button.Text == ".") 
            {
                if (!tbDisplayResult.Text.Contains(".")) ;
                tbDisplayResult.Text += button.Text;

             }
            else
            {
                tbDisplayResult.Text += button.Text;
            }
           

            
        }

        private void operator_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            operationPerformed = button.Text;
            resultValue = Double.Parse(tbDisplayResult.Text);
            lbCurrentOp.Text = resultValue + " " + operationPerformed;
            isoperationPerformed = true;


        }

        private void button17_Click(object sender, EventArgs e)
        {
            tbDisplayResult.Text = "0";
            
        }

        private void button16_Click(object sender, EventArgs e)
        {
            tbDisplayResult.Text = "0";
            resultValue = 0;
            lbCurrentOp.Text = null;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if  (operationPerformed == "+")
            {
                tbDisplayResult.Text = (resultValue + double.Parse(tbDisplayResult.Text)).ToString();

            }
            else if (operationPerformed == "-")
            {
                tbDisplayResult.Text = (resultValue - double.Parse(tbDisplayResult.Text)).ToString();
            }
            else if (operationPerformed == "×")
            {
                tbDisplayResult.Text = (resultValue * double.Parse(tbDisplayResult.Text)).ToString();
            } 
            else
            {
                tbDisplayResult.Text = (resultValue / double.Parse(tbDisplayResult.Text)).ToString();
            }
            

        }

        private void button18_Click(object sender, EventArgs e)
        {

        }
    }
}
